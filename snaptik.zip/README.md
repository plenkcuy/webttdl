Before you can get this to work, you must follow the two steps below.

1.) Go to https://rapidapi.com/ytjar/api/youtube-mp36 and get your free API key by choosing the freemium subscription plan.

2.) Add a .env file to the project and add the following variables: API_KEY and API_HOST. Initialize them with your credentials.
